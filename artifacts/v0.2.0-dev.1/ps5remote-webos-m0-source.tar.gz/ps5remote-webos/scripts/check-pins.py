#!/usr/bin/env python3
import pathlib,json,subprocess
root=pathlib.Path(__file__).resolve().parents[1]
for name,spec in json.loads((root/'upstream.lock.json').read_text()).items():
    if spec['role']!='build input':continue
    path=root/'upstream'/name
    assert subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True).strip()==spec['rev'],name+' revision mismatch'
    assert not subprocess.check_output(['git','-C',str(path),'status','--porcelain'],text=True).strip(),name+' is dirty'
print('Pinned build input revisions verified')
