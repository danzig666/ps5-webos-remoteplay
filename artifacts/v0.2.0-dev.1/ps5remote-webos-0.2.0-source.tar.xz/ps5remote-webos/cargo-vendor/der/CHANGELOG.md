# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 0.8.3 (2026-10-25)
### Added
- `AsBitStringRef` trait ([#2418])

### Fixed
- Off-by-one error in max nested message check ([#2424])
- Input validation in `SetOfRef` ([#2431])
- Require a `SEQUENCE` in `Document::decode` ([#2442])
- Order `SET OF` components by their encoded octets ([#2447])
- Order `UTCTime` in `SET OF` by its encoding ([#2448])
- `Option::der_cmp(None, None)` now returns `Equal` ([#2449])
- Infinite recursion in `ValueOrd` for `ContextSpecific` ([#2450])
- Order `FlagSet` by its `BIT STRING` encoding ([#2451])
- Avoid panic on truncated binary `REAL` values ([#2483])
- Stack overflow decoding nested BER indefinite lengths ([#2490])
- Recursion in `TryFrom<AnyRef<'_>>` impl for `bool` ([#2491])

[#2418]: https://github.com/RustCrypto/formats/pull/2418
[#2424]: https://github.com/RustCrypto/formats/pull/2424
[#2431]: https://github.com/RustCrypto/formats/pull/2431
[#2442]: https://github.com/RustCrypto/formats/pull/2442
[#2447]: https://github.com/RustCrypto/formats/pull/2447
[#2448]: https://github.com/RustCrypto/formats/pull/2448
[#2449]: https://github.com/RustCrypto/formats/pull/2449
[#2450]: https://github.com/RustCrypto/formats/pull/2450
[#2451]: https://github.com/RustCrypto/formats/pull/2451
[#2483]: https://github.com/RustCrypto/formats/pull/2483
[#2490]: https://github.com/RustCrypto/formats/pull/2490
[#2491]: https://github.com/RustCrypto/formats/pull/2491

## 0.8.2 (2026-09-05)
### Added
- `AsIntRef` and `AsUintRef` traits ([#2415])

### Fixed
- Return error on nested trailing data ([#2401])

[#2415]: https://github.com/RustCrypto/formats/pull/2415
[#2401]: https://github.com/RustCrypto/formats/pull/2401

## 0.8.1 (2026-07-08)
### Added
- `SetOfRef` struct ([#2247])

### Changed
- Deprecate `ErrorKind::SetDuplicate` ([#2276])
- Improve `SetOf*` sorting performance ([#2345])
- Cap maximum number of nested messages at `64` ([#2379])

### Fixed
- `SET OF` is not supposed to disallow duplicates ([#2272])

[#2247]: https://github.com/RustCrypto/for dwqmats/pull/2247
[#2272]: https://github.com/RustCrypto/formats/pull/2272
[#2276]: https://github.com/RustCrypto/formats/pull/2276
[#2345]: https://github.com/RustCrypto/formats/pull/2345
[#2379]: https://github.com/RustCrypto/formats/pull/2379

## 0.8.0 (2026-02-13) [YANKED]

NOTE: this release was yanked to fix a `minimal-versions` check in CI.

### Added
- Custom error types support to the `Decode` and `DecodeValue` traits ([#1055])
- `EncodingRules` enum ([#1321])
- `Decode::from_ber` ([#1389])
- Documentation for field-level `tag_mode` attribute ([#1401])
- `Hash` implementation for `AlgorithmIdentifier` ([#1414])
- `SequenceRef::as_bytes` and `AsRef<[u8]>` impl ([#1454])
- `Reader::peek_into` ([#1478])
- `GeneralString` variant to `Tag` ([#1512])
- Conversions from `OctetString(Ref)` to `Vec`/`Bytes` ([#1540])
- Custom error types in derive macros ([#1560])
- Support for tags beyond 30 ([#1651])
- Const `::new` to `Length`, `BytesRef`, and `AnyRef` ([#1713])
- Const `GeneralizedTime::from_date_time` ([#1718])
- `Decode::from_der_partial` ([#1725])
- Conversions between `BitStringRef`/`OctetStringRef` and `[u8; N]` ([#1731])
- Add class bits consts for Application and Private tag support ([#1721])
- conversions between `heapless:Vec<u8>` and `OctetStringRef` ([#1735])
- `IsConstructed` trait, impl'ed on any `FixedTag` ([#1744])
- Implement `Hash` for `SetOf` ([#1764])
- Implement `Uint`/`Int` conversions from native types ([#1762])
- Support for `APPLICATION`, `CONTEXT-SPECIFIC` and `PRIVATE` tags ([#1819], [#1825], [#1944])
- Support `Cow<[u8]>` in `derive(Sequence)` ([#1850])
- `diagnostic::on_unimplemented` attributes ([#1876])
- `Reader::read_value`, auto-nest `DecodeValue` ([#1877], [#1895], [#1897], [#1901])
- Indefinite length support for BER ([#1884], [#1885], [#1894], [#1900], [#1902], [#1910])
- Constructed OctetString support ([#1899], [#1922])
- string conversions, predicate methods for EncodingRules ([#1903], [#1953])
- `Any::header` ([#1935])
- `Tag::RelativeOid` ([#1942])
- `ber` feature ([#1948], [#1950])
- Hash derive for `StringOwned` and `Ia5String` ([#1973])
- Implement `DecodeValue/EncodeValue/Tagged` for `Cow` ([#2093])
- Add doc examples for `EncodeValue`, `Encode`, `DecodeValue`, `Decode`, `Error`, `ErrorKind`, `Tagged`, `FixedTag`,
  `IsConstructed`, `Tag`, `Length`, `Header` ([#2075], [#2071], [#2070], [#2064], [#2058], [#2052], [#2053], [#2051])
- `SequenceRef::new` ([#2224])

### Changed
- Return `Tag::Integer.length_error()` on empty ints ([#1400])
- Allow all blanket impls on `?Sized` types ([#1451])
- Refactor `Tag::peek` ([#1479])
- Refactor `Header::peek` ([#1480])
- Use `core::error::Error` ([#1553])
- Use 2024 edition, bump MSRV to 1.85 ([#1670])
- Bump `const-oid` to v0.10 ([#1676])
- Reject zero lengths reads ([#1716])
- Deprecate `TagNumber::new` ([#1727])
- Use strict context-specific skipping condition (equal tag numbers only) ([#1740])
- Const `Any::to_ref`, `BytesOwned::to_ref` ([#1797])
- Return `ErrorKind::Noncanonical` in `EXPLICIT` when primitive ([#1818])
- Use `read_nested` to check length of `IMPLICIT` types ([#1739])
- Simplify `From<&UintRef<'a>>` for `Uint` ([#1840])
- Make `ObjectIdentifier<MAX_SIZE>` impls generic ([#1851])
- Extract `reader::position::Position` ([#1880])
- Make `Reader` cloneable ([#1883])
- Simplify `Header::peek` and `Tag::peek` ([#1886])
- Improve constructed bit handling ([#1919])
- Use fat pointer in `OctetStringRef`, consolidate bytes/string modules, improve internal ref types
  ([#1920], [#1921], [#1998], [#2040])
- Change constructor `Header::new`, add `Header::with_length`, tests for constructed octet string ([#1931], [#1930])
- Simplify `der_cmp` for `Length` ([#1997])
- Rename variable encoder -> writer and improve example ([#2078])
- Have `PemReader` decode to `Cow::Owned` ([#2094])
- Only sort `SET OF` types with `EncodingRules::Der` ([#2219])
- `SetOf` and `SequenceOf` now require `heapless` feature ([#2220], [#2229])

### Fixed
- Append in `Encode::encode_to_vec` ([#1760])
- Derive optional OCTET/BIT STRING on `Option<&[u8]>` ([#1737])
- X.680 tag order: compare class and number first ([#1790])
- BMPString compatibility in derive macros ([#1793])
- `Tag::peek_optional` for 6-byte and 7+ byte tags ([#1804])
- `Header::peek` for 11-byte tag-lengths ([#1828])
- Panic in `value_cmp`: add `Iterator::size_hint` ([#1830])
- Error position tracking improvements ([#1889], [#2080], [#2079])
- Bound `Decode(Value)::Error` on `core::error::Error` ([#2137])
- Have `SetOf(Vec)::insert` check for duplicates ([#2217])

### Removed
- `TagNumber::N0..N30` consts ([#1724])
- 256MiB limit on `Length` ([#1726])
- Generic `<T>` from `Reader::finish` ([#1833])
- Deprecated `SetOf(Vec)::add` methods ([#2232])
- `SequenceRef` lifetime ([#2224])

[#1055]: https://github.com/RustCrypto/formats/pull/1055
[#1321]: https://github.com/RustCrypto/formats/pull/1321
[#1389]: https://github.com/RustCrypto/formats/pull/1389
[#1400]: https://github.com/RustCrypto/formats/pull/1400
[#1401]: https://github.com/RustCrypto/formats/pull/1401
[#1414]: https://github.com/RustCrypto/formats/pull/1414
[#1451]: https://github.com/RustCrypto/formats/pull/1451
[#1454]: https://github.com/RustCrypto/formats/pull/1454
[#1478]: https://github.com/RustCrypto/formats/pull/1478
[#1479]: https://github.com/RustCrypto/formats/pull/1479
[#1480]: https://github.com/RustCrypto/formats/pull/1480
[#1512]: https://github.com/RustCrypto/formats/pull/1512
[#1540]: https://github.com/RustCrypto/formats/pull/1540
[#1553]: https://github.com/RustCrypto/formats/pull/1553
[#1560]: https://github.com/RustCrypto/formats/pull/1560
[#1651]: https://github.com/RustCrypto/formats/pull/1651
[#1670]: https://github.com/RustCrypto/formats/pull/1670
[#1676]: https://github.com/RustCrypto/formats/pull/1676
[#1713]: https://github.com/RustCrypto/formats/pull/1713
[#1716]: https://github.com/RustCrypto/formats/pull/1716
[#1718]: https://github.com/RustCrypto/formats/pull/1718
[#1721]: https://github.com/RustCrypto/formats/pull/1721
[#1724]: https://github.com/RustCrypto/formats/pull/1724
[#1725]: https://github.com/RustCrypto/formats/pull/1725
[#1726]: https://github.com/RustCrypto/formats/pull/1726
[#1727]: https://github.com/RustCrypto/formats/pull/1727
[#1731]: https://github.com/RustCrypto/formats/pull/1731
[#1735]: https://github.com/RustCrypto/formats/pull/1735
[#1737]: https://github.com/RustCrypto/formats/pull/1737
[#1739]: https://github.com/RustCrypto/formats/pull/1739
[#1760]: https://github.com/RustCrypto/formats/pull/1760
[#1762]: https://github.com/RustCrypto/formats/pull/1762
[#1764]: https://github.com/RustCrypto/formats/pull/1764
[#1740]: https://github.com/RustCrypto/formats/pull/1740
[#1744]: https://github.com/RustCrypto/formats/pull/1744
[#1790]: https://github.com/RustCrypto/formats/pull/1790
[#1793]: https://github.com/RustCrypto/formats/pull/1793
[#1797]: https://github.com/RustCrypto/formats/pull/1797
[#1804]: https://github.com/RustCrypto/formats/pull/1804
[#1818]: https://github.com/RustCrypto/formats/pull/1818
[#1819]: https://github.com/RustCrypto/formats/pull/1819
[#1825]: https://github.com/RustCrypto/formats/pull/1825
[#1828]: https://github.com/RustCrypto/formats/pull/1828
[#1830]: https://github.com/RustCrypto/formats/pull/1830
[#1833]: https://github.com/RustCrypto/formats/pull/1833
[#1840]: https://github.com/RustCrypto/formats/pull/1840
[#1850]: https://github.com/RustCrypto/formats/pull/1850
[#1851]: https://github.com/RustCrypto/formats/pull/1851
[#1876]: https://github.com/RustCrypto/formats/pull/1876
[#1877]: https://github.com/RustCrypto/formats/pull/1877
[#1880]: https://github.com/RustCrypto/formats/pull/1880
[#1883]: https://github.com/RustCrypto/formats/pull/1883
[#1884]: https://github.com/RustCrypto/formats/pull/1884
[#1885]: https://github.com/RustCrypto/formats/pull/1885
[#1886]: https://github.com/RustCrypto/formats/pull/1886
[#1889]: https://github.com/RustCrypto/formats/pull/1889
[#1894]: https://github.com/RustCrypto/formats/pull/1894
[#1895]: https://github.com/RustCrypto/formats/pull/1895
[#1897]: https://github.com/RustCrypto/formats/pull/1897
[#1899]: https://github.com/RustCrypto/formats/pull/1899
[#1900]: https://github.com/RustCrypto/formats/pull/1900
[#1901]: https://github.com/RustCrypto/formats/pull/1901
[#1902]: https://github.com/RustCrypto/formats/pull/1902
[#1903]: https://github.com/RustCrypto/formats/pull/1903
[#1910]: https://github.com/RustCrypto/formats/pull/1910
[#1919]: https://github.com/RustCrypto/formats/pull/1919
[#1920]: https://github.com/RustCrypto/formats/pull/1920
[#1921]: https://github.com/RustCrypto/formats/pull/1921
[#1922]: https://github.com/RustCrypto/formats/pull/1922
[#1930]: https://github.com/RustCrypto/formats/pull/1930
[#1931]: https://github.com/RustCrypto/formats/pull/1931
[#1935]: https://github.com/RustCrypto/formats/pull/1935
[#1942]: https://github.com/RustCrypto/formats/pull/1942
[#1944]: https://github.com/RustCrypto/formats/pull/1944
[#1948]: https://github.com/RustCrypto/formats/pull/1948
[#1950]: https://github.com/RustCrypto/formats/pull/1950
[#1953]: https://github.com/RustCrypto/formats/pull/1953
[#1973]: https://github.com/RustCrypto/formats/pull/1973
[#1997]: https://github.com/RustCrypto/formats/pull/1997
[#1998]: https://github.com/RustCrypto/formats/pull/1998
[#2137]: https://github.com/RustCrypto/formats/pull/2137
[#2040]: https://github.com/RustCrypto/formats/pull/2040
[#2051]: https://github.com/RustCrypto/formats/pull/2051
[#2052]: https://github.com/RustCrypto/formats/pull/2052
[#2053]: https://github.com/RustCrypto/formats/pull/2053
[#2058]: https://github.com/RustCrypto/formats/pull/2058
[#2064]: https://github.com/RustCrypto/formats/pull/2064
[#2070]: https://github.com/RustCrypto/formats/pull/2070
[#2071]: https://github.com/RustCrypto/formats/pull/2071
[#2075]: https://github.com/RustCrypto/formats/pull/2075
[#2078]: https://github.com/RustCrypto/formats/pull/2078
[#2079]: https://github.com/RustCrypto/formats/pull/2079
[#2080]: https://github.com/RustCrypto/formats/pull/2080
[#2093]: https://github.com/RustCrypto/formats/pull/2093
[#2094]: https://github.com/RustCrypto/formats/pull/2094
[#2217]: https://github.com/RustCrypto/formats/pull/2217
[#2219]: https://github.com/RustCrypto/formats/pull/2219
[#2220]: https://github.com/RustCrypto/formats/pull/2220
[#2224]: https://github.com/RustCrypto/formats/pull/2224
[#2229]: https://github.com/RustCrypto/formats/pull/2229
[#2232]: https://github.com/RustCrypto/formats/pull/2232

## 0.7.10 (2024-04-18)
### Fixed
- append in `Encode::encode_to_vec` (backport [#1760])

[#1760]: https://github.com/RustCrypto/formats/pull/1760

## 0.7.9 (2024-04-01)
### Changed
- make sure der is comptatible with potential language breaking changed (backport [#1374])

[#1374]: https://github.com/RustCrypto/formats/pull/1374

## 0.7.8 (2023-08-07)
### Added
- `bytes` feature ([#1156])
- impl `RefToOwned`/`OwnedToRef` for `&[u8]`/`Box<[u8]>` ([#1188])
- `BmpString` ([#1164])

### Changed
- no-panic cleanup ([#1169])
- Bump `der_derive` dependency to v0.7.2 ([#1192])

[#1156]: https://github.com/RustCrypto/formats/pull/1156
[#1164]: https://github.com/RustCrypto/formats/pull/1164
[#1169]: https://github.com/RustCrypto/formats/pull/1169
[#1188]: https://github.com/RustCrypto/formats/pull/1188
[#1192]: https://github.com/RustCrypto/formats/pull/1192

## 0.7.7 (2023-06-29)
### Added
- `TryFrom<String>` impl for strings based on `StrOwned` ([#1064])

[#1064]: https://github.com/RustCrypto/formats/pull/1064

## 0.7.6 (2023-05-16)
### Added
- `SetOfVec::{extend, from_iter}` methods ([#1065])
- `SetOf(Vec)::{insert, insert_ordered}` methods ([#1067])

### Changed
- Deprecate `SetOf(Vec)::add` ([#1067])

### Fixed
- Off-by-one error in `BMPString` tag ([#1037])
- Handling of non-unique items in `SetOf`(Vec) ([#1066])

[#1037]: https://github.com/RustCrypto/formats/pull/1037
[#1065]: https://github.com/RustCrypto/formats/pull/1065
[#1066]: https://github.com/RustCrypto/formats/pull/1066
[#1067]: https://github.com/RustCrypto/formats/pull/1067

## 0.7.5 (2023-04-24)
### Added
- adds support for `DateTime::INFINITY` ([#1026])

[#1026]: https://github.com/RustCrypto/formats/pull/1026

## 0.7.4 (2023-04-19)
### Added
- `Decode` and `Encode` impls for `PhantomData` ([#1009])
- `ValueOrd` and `DerOrd` impls for `PhantomData` ([#1012])

### Changed
- Bump `hex-literal` dependency to v0.4.1 ([#999])
- Bump `der_derive` dependency to v0.7.1 ([#1016])

[#1009]: https://github.com/RustCrypto/formats/pull/1009
[#1012]: https://github.com/RustCrypto/formats/pull/1012
[#1016]: https://github.com/RustCrypto/formats/pull/1016

## 0.7.3 (2023-04-06)
### Added
- `UtcTime::MAX_YEAR` associated constant ([#989])

[#989]: https://github.com/RustCrypto/formats/pull/989

## 0.7.2 (2023-04-04)
### Added
- Expose `NestedReader ([#925])
- `From<ObjectIdentifier>` impl for `Any` ([#965])
- `Any::null` helper ([#969])
- `Any::encode_from` ([#976])

[#925]: https://github.com/RustCrypto/formats/pull/925
[#965]: https://github.com/RustCrypto/formats/pull/965
[#969]: https://github.com/RustCrypto/formats/pull/969
[#976]: https://github.com/RustCrypto/formats/pull/976

## 0.7.1 (2023-03-07)
### Changed
- Make `zeroize`'s `alloc` feature conditional ([#920])

[#920]: https://github.com/RustCrypto/formats/pull/920

## 0.7.0 (2023-02-26) [YANKED]
### Added
- `OwnedtoRef`/`RefToOwned` traits; MSRV 1.65 ([#797])
- `OctetStringRef::decode_into` ([#817])
- `Int` and `IntRef` types ([#823])
- `IndefiniteLength` type ([#830])
- `Any::value` accessor ([#833])
- Buffered PEM reader ([#839])
- `OctetString::into_bytes` ([#845])
- Blanket impls on `Box<T>` for `DecodeValue`, `EncodeValue`, and `Sequence` ([#860])

### Changed
- Rename `UIntRef` => `UintRef` ([#786])
- Replace use of `dyn Writer` with `impl Writer` ([#828])
- Rename `AnyRef::decode_into` -> `::decode_as` ([#829])
- Bump `pem-rfc7468` dependency to v0.7 ([#894])
- Rename `Encode::to_vec` => `::to_der` ([#898])

### Removed
- `Sequence::fields` method ([#828])
- Inherent `AnyRef` decoding methods ([#829])

[#786]: https://github.com/RustCrypto/formats/pull/786
[#797]: https://github.com/RustCrypto/formats/pull/797
[#817]: https://github.com/RustCrypto/formats/pull/817
[#823]: https://github.com/RustCrypto/formats/pull/823
[#828]: https://github.com/RustCrypto/formats/pull/828
[#829]: https://github.com/RustCrypto/formats/pull/829
[#830]: https://github.com/RustCrypto/formats/pull/830
[#833]: https://github.com/RustCrypto/formats/pull/833
[#839]: https://github.com/RustCrypto/formats/pull/839
[#845]: https://github.com/RustCrypto/formats/pull/845
[#860]: https://github.com/RustCrypto/formats/pull/860
[#894]: https://github.com/RustCrypto/formats/pull/894
[#898]: https://github.com/RustCrypto/formats/pull/898

## 0.6.1 (2022-12-05)
### Added
- Rudimentary implementation of `TeletexString` and `VideotexString` ([#691])
- Impl `ValueOrd` for `FlagSet<T>` and `UIntRef` ([#723])

### Changed
- Eliminate some boilerplate code by using `Deref` ([#697])

[#691]: https://github.com/RustCrypto/formats/pull/691
[#697]: https://github.com/RustCrypto/formats/pull/697
[#723]: https://github.com/RustCrypto/formats/pull/723

## 0.6.0 (2022-05-08)
### Added
- Impl `ValueOrd` for `SetOf` and `SetOfVec` ([#362])
- `SequenceRef` type ([#374])
- Support for `SetOf` sorting on heapless `no_std` targets ([#401])
- Support for mapping `BitString` to/from a `FlagSet` ([#412])
- `DecodeOwned` marker trait ([#529])
- Support for the ASN.1 `REAL` type ([#346])
- `DecodePem` and `EncodePem` traits ([#571])
- `Document` and `SecretDocument` types ([#571])
- `EncodeRef`/`EncodeValueRef` wrapper types ([#604])
- `Writer` trait ([#605])
- `Reader` trait ([#606])
- Streaming on-the-fly `PemReader` and `PemWriter` ([#618], [#636])
- Owned `BitString` ([#636])
- Owned `Any` and `OctetString` types ([#640])

### Changed
- Pass `Header` to `DecodeValue` ([#392])
- Bump `const-oid` dependency to v0.9 ([#507])
- Renamed `Decodable`/`Encodable` => `Decode`/`Encode` ([#523])
- Enable arithmetic, casting, and panic `clippy` lints ([#556], [#579])
- Use `&mut dyn Writer` as output for `Encode::encode` and `EncodeValue::encode_value` ([#611])
- Bump `pem-rfc7468` dependency to v0.6 ([#620])
- Use `Reader<'a>` as input for `Decode::decode` and `DecodeValue::decode_value` ([#633])
- Renamed `Any` => `AnyRef` ([#637])
- Renamed `BitString` => `BitStringRef` ([#637])
- Renamed `Ia5String` => `Ia5StringRef` ([#637])
- Renamed `OctetString` => `OctetStringRef` ([#637])
- Renamed `PrintableString` => `PrintableStringRef` ([#637])
- Renamed `Utf8String` => `Utf8StringRef` ([#637])
- Renamed `UIntBytes` => `UIntRef` ([#637])
- Renamed `Decoder` => `SliceReader` ([#651])
- Renamed `Encoder` => `SliceWriter` ([#651])

### Fixed
- Handling of oversized unsigned `INTEGER` inputs ([#447])

### Removed
- `bigint` feature ([#344])
- `OrdIsValueOrd` trait ([#359])
- `Document` trait ([#571])
- `OptionalRef` ([#604])
- Decode-time SET OF ordering checks ([#625])

[#344]: https://github.com/RustCrypto/formats/pull/344
[#346]: https://github.com/RustCrypto/formats/pull/346
[#359]: https://github.com/RustCrypto/formats/pull/359
[#362]: https://github.com/RustCrypto/formats/pull/362
[#374]: https://github.com/RustCrypto/formats/pull/374
[#392]: https://github.com/RustCrypto/formats/pull/392
[#401]: https://github.com/RustCrypto/formats/pull/401
[#412]: https://github.com/RustCrypto/formats/pull/412
[#447]: https://github.com/RustCrypto/formats/pull/447
[#507]: https://github.com/RustCrypto/formats/pull/507
[#523]: https://github.com/RustCrypto/formats/pull/523
[#529]: https://github.com/RustCrypto/formats/pull/529
[#556]: https://github.com/RustCrypto/formats/pull/556
[#571]: https://github.com/RustCrypto/formats/pull/571
[#579]: https://github.com/RustCrypto/formats/pull/579
[#604]: https://github.com/RustCrypto/formats/pull/604
[#605]: https://github.com/RustCrypto/formats/pull/605
[#606]: https://github.com/RustCrypto/formats/pull/606
[#611]: https://github.com/RustCrypto/formats/pull/611
[#618]: https://github.com/RustCrypto/formats/pull/618
[#620]: https://github.com/RustCrypto/formats/pull/620
[#625]: https://github.com/RustCrypto/formats/pull/625
[#633]: https://github.com/RustCrypto/formats/pull/633
[#636]: https://github.com/RustCrypto/formats/pull/636
[#637]: https://github.com/RustCrypto/formats/pull/637
[#640]: https://github.com/RustCrypto/formats/pull/640
[#651]: https://github.com/RustCrypto/formats/pull/651

## 0.5.1 (2021-11-17)
### Added
- `Any::NULL` constant ([#226])

[#226]: https://github.com/RustCrypto/formats/pull/226

## 0.5.0 (2021-11-15) [YANKED]
### Added
- Support for `IMPLICIT` mode `CONTEXT-SPECIFIC` fields ([#61])
- `DecodeValue`/`EncodeValue` traits ([#63])
- Expose `DateTime` through public API ([#75])
- `SEQUENCE OF` support for `[T; N]` ([#90])
- `SequenceOf` type ([#95])
- `SEQUENCE OF` support for `Vec` ([#96])
- `Document` trait ([#117])
- Basic integration with `time` crate ([#129])
- `Tag::NumericString` ([#132])
- Support for unused bits to `BitString` ([#141])
- `Decoder::{peek_tag, peek_header}` ([#142])
- Type hint in `encoder `sequence` method ([#147])
- `Tag::Enumerated` ([#153])
- `ErrorKind::TagNumberInvalid` ([#156])
- `Tag::VisibleString` and `Tag::BmpString` ([#160])
- Inherent constants for all valid `TagNumber`s ([#165])
- `DerOrd` and `ValueOrd` traits ([#190])
- `ContextSpecificRef` type ([#199])

### Changed
- Make `ContextSpecific` generic around an inner type ([#60])
- Removed `SetOf` trait; rename `SetOfArray` => `SetOf` ([#97])
- Rename `Message` trait to `Sequence` ([#99])
- Make `GeneralizedTime`/`UtcTime` into `DateTime` newtypes ([#102])
- Rust 2021 edition upgrade; MSRV 1.56 ([#136])
- Replace `ErrorKind::Truncated` with `ErrorKind::Incomplete` ([#143])
- Rename `ErrorKind::UnknownTagMode` => `ErrorKind::TagModeUnknown` ([#155])
- Rename `ErrorKind::UnexpectedTag` => `ErrorKind::TagUnexpected` ([#155])
- Rename `ErrorKind::UnknownTag` => `ErrorKind::TagUnknown` ([#155])
- Consolidate `ErrorKind::{Incomplete, Underlength}` ([#157])
- Rename `Tagged` => `FixedTag`; add new `Tagged` trait ([#189])
- Use `DerOrd` for `SetOf*` types ([#200])
- Switch `impl From<BitString> for &[u8]` to `TryFrom` ([#203])
- Bump `crypto-bigint` dependency to v0.3 ([#215])
- Bump `const-oid` dependency to v0.7 ([#216])
- Bump `pem-rfc7468` dependency to v0.3 ([#217])
- Bump `der_derive` dependency to v0.5 ([#221])

### Removed
- `Sequence` struct ([#98])
- `Tagged` bound on `ContextSpecific::decode_implicit` ([#161])
- `ErrorKind::DuplicateField` ([#162])

[#60]: https://github.com/RustCrypto/formats/pull/60
[#61]: https://github.com/RustCrypto/formats/pull/61
[#63]: https://github.com/RustCrypto/formats/pull/63
[#75]: https://github.com/RustCrypto/formats/pull/75
[#90]: https://github.com/RustCrypto/formats/pull/90
[#95]: https://github.com/RustCrypto/formats/pull/95
[#96]: https://github.com/RustCrypto/formats/pull/96
[#97]: https://github.com/RustCrypto/formats/pull/97
[#98]: https://github.com/RustCrypto/formats/pull/98
[#99]: https://github.com/RustCrypto/formats/pull/99
[#102]: https://github.com/RustCrypto/formats/pull/102
[#117]: https://github.com/RustCrypto/formats/pull/117
[#129]: https://github.com/RustCrypto/formats/pull/129
[#132]: https://github.com/RustCrypto/formats/pull/132
[#136]: https://github.com/RustCrypto/formats/pull/136
[#141]: https://github.com/RustCrypto/formats/pull/141
[#142]: https://github.com/RustCrypto/formats/pull/142
[#143]: https://github.com/RustCrypto/formats/pull/143
[#147]: https://github.com/RustCrypto/formats/pull/147
[#153]: https://github.com/RustCrypto/formats/pull/153
[#155]: https://github.com/RustCrypto/formats/pull/155
[#156]: https://github.com/RustCrypto/formats/pull/156
[#157]: https://github.com/RustCrypto/formats/pull/157
[#160]: https://github.com/RustCrypto/formats/pull/160
[#161]: https://github.com/RustCrypto/formats/pull/161
[#162]: https://github.com/RustCrypto/formats/pull/162
[#165]: https://github.com/RustCrypto/formats/pull/165
[#189]: https://github.com/RustCrypto/formats/pull/189
[#190]: https://github.com/RustCrypto/formats/pull/190
[#199]: https://github.com/RustCrypto/formats/pull/199
[#200]: https://github.com/RustCrypto/formats/pull/200
[#203]: https://github.com/RustCrypto/formats/pull/203
[#215]: https://github.com/RustCrypto/formats/pull/215
[#216]: https://github.com/RustCrypto/formats/pull/216
[#217]: https://github.com/RustCrypto/formats/pull/217
[#221]: https://github.com/RustCrypto/formats/pull/221

## 0.4.5 (2021-12-01)
### Fixed
- Backport [#147] type hint fix for WASM platforms to 0.4.x

## 0.4.4 (2021-10-06)
### Removed
- Accidentally checked-in `target/` directory ([#66])

[#66]: https://github.com/RustCrypto/formats/pull/66

## 0.4.3 (2021-09-15)
### Added
- `Tag::unexpected_error` ([#33])

[#33]: https://github.com/RustCrypto/formats/pull/33

## 0.4.2 (2021-09-14)
### Changed
- Moved to `formats` repo ([#2])

### Fixed
- ASN.1 `SET` type now flagged with the constructed bit

[#2]: https://github.com/RustCrypto/formats/pull/2

## 0.4.1 (2021-08-08)
### Fixed
- Encoding `UTCTime` for dates with `20xx` years

## 0.4.0 (2021-06-07)
### Added
- `TagNumber` type
- Const generic integer de/encoders with support for all of Rust's integer
  primitives
- `crypto-bigint` support
- `Tag` number helpers
- `Tag::octet`
- `ErrorKind::Value` helpers
- `SequenceIter`

### Changed
- Bump `const-oid` crate dependency to v0.6
- Make `Tag` structured
- Namespace ASN.1 types in `asn1` module
- Refactor context-specific field decoding
- MSRV 1.51
- Rename `big-uint` crate feature to `bigint`
- Rename `BigUInt` to `UIntBytes`
- Have `Decoder::error()` return an `Error`
  
### Removed
- Deprecated methods replaced by associated constants

## 0.3.5 (2021-05-24)
### Added
- Helper methods for context-specific fields
- `ContextSpecific` field wrapper
- Decoder position tracking for errors during `Any<'a>` decoding

### Fixed
- `From` conversion for `BitString` into `Any`

## 0.3.4 (2021-05-16)
### Changed
- Support `Length` of up to 1 MiB

## 0.3.3 (2021-04-15)
### Added
- `Length` constants

### Changed
- Deprecate `const fn` methods replaced by `Length` constants

## 0.3.2 (2021-04-15)
### Fixed
- Non-critical bug allowing `Length` to exceed the max invariant

## 0.3.1 (2021-04-01) [YANKED]
### Added
- `PartialOrd` + `Ord` impls to all ASN.1 types

## 0.3.0 (2021-03-22) [YANKED]
### Added
- Impl `Decode`/`Encoded`/`Tagged` for `String`
- `Length::one` and `Length::for_tlv`
- `SET OF` support with `SetOf` trait and `SetOfRef`

### Changed
- Rename `Decodable::from_bytes` => `Decodable::from_der`
- Separate `sequence` and `message`
- Rename `ErrorKind::Oid` => `ErrorKind::MalformedOid`
- Auto-derive `From` impls for variants when deriving `Choice`
- Make `Length` use `u32` internally
- Make `Sequence` constructor private
- Bump `const_oid` to v0.5
- Bump `der_derive` to v0.3

### Removed
- Deprecated methods
- `BigUIntSize`

## 0.2.10 (2021-02-28)
### Added
- Impl `From<ObjectIdentifier>` for `Any`

### Changed
- Bump minimum `const-oid` dependency to v0.4.4

## 0.2.9 (2021-02-24)
### Added
- Support for `IA5String`

## 0.2.8 (2021-02-22)
### Added
- `Choice` trait

## 0.2.7 (2021-02-20)
### Added
- Export `Header` publicly
- Make `Encoder::reserve` public

## 0.2.6 (2021-02-19)
### Added
- Make the unit type an encoding of `NULL`

## 0.2.5 (2021-02-18)
### Added
- `ErrorKind::UnknownOid` variant

## 0.2.4 (2021-02-16)
### Added
- `Any::is_null` method

### Changed
- Deprecate `Any::null` method

## 0.2.3 (2021-02-15)
### Added
- Additional `rustdoc` documentation

## 0.2.2 (2021-02-12)
### Added
- Support for `UTCTime` and `GeneralizedTime`

## 0.2.1 (2021-02-02)
### Added
- Support for `PrintableString` and `Utf8String`

## 0.2.0 (2021-01-22)
### Added
- `BigUInt` type
- `i16` support
- `u8` and `u16` support
- Integer decoder helper methods

### Fixed
- Handle leading byte of `BIT STRING`s

## 0.1.0 (2020-12-21)
- Initial release
