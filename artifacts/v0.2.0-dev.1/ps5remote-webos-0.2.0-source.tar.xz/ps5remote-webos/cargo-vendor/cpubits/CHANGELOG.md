# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 0.1.1 (2026-04-28)
### Fixed
- Output for 16-bit targets ([#1470])

[#1470]: https://github.com/RustCrypto/utils/pull/1470

## 0.1.0 (2026-02-22)
Initial release
