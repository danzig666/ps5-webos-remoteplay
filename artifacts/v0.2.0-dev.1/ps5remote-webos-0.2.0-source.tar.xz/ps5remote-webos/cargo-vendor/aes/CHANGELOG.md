# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 0.9.3 (2026-08-28)
### Changed
- MSRV bumped to 1.89 ([#580])
- VAES-256 and VAES-512 backends on x86 targets are now supported by default ([#580])
- Disable `aarch64_aes` backend on Miri ([#586])

### Removed
- `aes_backend = "avx256"` and `aes_backend = "avx512"` configuration flags ([#580])

[#580]: https://github.com/RustCrypto/block-ciphers/pull/580
[#586]: https://github.com/RustCrypto/block-ciphers/pull/586

## 0.9.2 (2026-07-27)
### Added
- `hardware_accelerated` function ([#579])

### Changed
- Internal implementation of backends ([#560], [#575])

### Fixed
- Performance regression on x86 targets ([#575])

[#560]: https://github.com/RustCrypto/block-ciphers/pull/560
[#575]: https://github.com/RustCrypto/block-ciphers/pull/575
[#579]: https://github.com/RustCrypto/block-ciphers/pull/579

## 0.9.1 (2026-05-27)
### Fixed
- Minimal version of `zeroize` dependency ([#562])
- Build warnings on AArch64 targets ([#562])

[#562]: https://github.com/RustCrypto/block-ciphers/pull/562

## 0.9.0 (2026-04-10) [YANKED]
### Changed
- Bump `cipher` dependency to v0.5
- Edition changed to 2024 and MSRV bumped to 1.85 ([#472])
- Refactor ARMv8 `expand_key` ([#367])
- Added `#[inline]` attributes for `KeyInit::new` impls ([#386])
- Rework backends ([#442])
- Move `Block8` to the hazmat module ([#468])
- Relax MSRV policy and allow MSRV bumps in patch releases ([#477])
- Replace inline ASM with ARMv8 intrinsics ([#380])
- Enable ARMv8 backend by default ([#395])

[#367]: https://github.com/RustCrypto/block-ciphers/pull/367
[#380]: https://github.com/RustCrypto/block-ciphers/pull/380
[#386]: https://github.com/RustCrypto/block-ciphers/pull/386
[#395]: https://github.com/RustCrypto/block-ciphers/pull/395
[#442]: https://github.com/RustCrypto/block-ciphers/pull/442
[#468]: https://github.com/RustCrypto/block-ciphers/pull/468
[#472]: https://github.com/RustCrypto/block-ciphers/pull/472
[#477]: https://github.com/RustCrypto/block-ciphers/pull/477

## 0.8.4 (2024-02-13)
### Changed
- Assert soundness preconditions for ARMv8 key expansion ([#407], [#408])

[#407]: https://github.com/RustCrypto/block-ciphers/pull/407
[#408]: https://github.com/RustCrypto/block-ciphers/pull/408

## 0.8.3 (2023-06-17)
### Added
- Support `aes_armv8` on Rust 1.61+ using `asm!` ([#365])

[#365]: https://github.com/RustCrypto/block-ciphers/pull/365

## 0.8.2 (2022-10-27)
### Fixed
- Crate documentation around configuration flags ([#343])

[#343]: https://github.com/RustCrypto/block-ciphers/pull/343

## 0.8.1 (2022-02-17)
### Fixed
- Minimal versions build ([#303])

[#303]: https://github.com/RustCrypto/block-ciphers/pull/303

## 0.8.0 (2022-02-10)
### Changed
- Bump `cipher` dependency to v0.4 ([#284])

### Added
- Encrypt-only and decrypt-only cipher types ([#284])

[#284]: https://github.com/RustCrypto/block-ciphers/pull/284

## 0.7.5 (2021-08-26)
### Changed
- Bump `ctr` dependency to v0.8 ([#275])
- Use the `aes` target feature instead of `crypto` on ARMv8 ([#279])
- Use `core::arch::aarch64::vst1q_u8` intrinsic on `armv8` ([#280])
- Bump `cpufeatures` dependency to v0.2 ([#281])

[#275]: https://github.com/RustCrypto/block-ciphers/pull/275
[#279]: https://github.com/RustCrypto/block-ciphers/pull/279
[#280]: https://github.com/RustCrypto/block-ciphers/pull/280
[#281]: https://github.com/RustCrypto/block-ciphers/pull/281

## 0.7.4 (2021-06-01)
### Added
- Soft `hazmat` backend ([#267], [#268])
- Parallel `hazmat` APIs ([#269])

[#267]: https://github.com/RustCrypto/block-ciphers/pull/267
[#268]: https://github.com/RustCrypto/block-ciphers/pull/268
[#269]: https://github.com/RustCrypto/block-ciphers/pull/269

## 0.7.3 (2021-05-26)
### Added
- `hazmat` feature/module providing round function access ([#257], [#259], [#260])
- `BLOCK_SIZE` constant ([#263])

[#257]: https://github.com/RustCrypto/block-ciphers/pull/257
[#259]: https://github.com/RustCrypto/block-ciphers/pull/259
[#260]: https://github.com/RustCrypto/block-ciphers/pull/260
[#263]: https://github.com/RustCrypto/block-ciphers/pull/263

## 0.7.2 (2021-05-17)
### Added
- Nightly-only ARMv8 intrinsics support gated under the `armv8` feature ([#250])

[#250]: https://github.com/RustCrypto/block-ciphers/pull/250

## 0.7.1 (2021-05-09)
### Fixed
- Restore `fixslice64.rs` ([#247])

[#247]: https://github.com/RustCrypto/block-ciphers/pull/247

## 0.7.0 (2021-04-29)
### Added
- Auto-detection support for AES-NI; MSRV 1.49+ ([#208], [#214], [#215], [#216])
- `ctr` feature providing SIMD accelerated AES-CTR ([#200])

### Changed
- Unify the `aes`, `aesni`, `aes-ctr`, and `aes-soft` crates ([#200])
- Use `cfg-if` crate ([#203])
- Rename `semi_fixslice` feature to `compact` ([#204])
- Refactor NI backend ([#224], [#225])
- Bump `cipher` crate dependency to v0.3 ([#235])
- Bump `ctr` crate dependency to v0.7 ([#237])

[#200]: https://github.com/RustCrypto/block-ciphers/pull/200
[#203]: https://github.com/RustCrypto/block-ciphers/pull/203
[#204]: https://github.com/RustCrypto/block-ciphers/pull/204
[#208]: https://github.com/RustCrypto/block-ciphers/pull/208
[#214]: https://github.com/RustCrypto/block-ciphers/pull/214
[#215]: https://github.com/RustCrypto/block-ciphers/pull/215
[#216]: https://github.com/RustCrypto/block-ciphers/pull/216
[#224]: https://github.com/RustCrypto/block-ciphers/pull/224
[#225]: https://github.com/RustCrypto/block-ciphers/pull/225
[#235]: https://github.com/RustCrypto/block-ciphers/pull/235
[#237]: https://github.com/RustCrypto/block-ciphers/pull/237

## 0.6.0 (2020-10-16)
### Changed
- Replace `block-cipher`/`stream-cipher` with `cipher` crate ([#167])

[#167]: https://github.com/RustCrypto/block-ciphers/pull/167

## 0.5.1 (2020-08-25)
### Changed
- Bump `aesni` dependency to v0.9 ([#158])

[#158]: https://github.com/RustCrypto/block-ciphers/pull/158

## 0.5.0 (2020-08-07)
### Changed
- Bump `block-cipher` dependency to v0.8 ([#138])
- Bump `opaque-debug` dependency to v0.3 ([#140])

[#138]: https://github.com/RustCrypto/block-ciphers/pull/138
[#140]: https://github.com/RustCrypto/block-ciphers/pull/140

## 0.4.0 (2020-06-05)
### Changed
- Bump `block-cipher` dependency to v0.7 ([#86], [#122])
- Update to Rust 2018 edition ([#86])

[#121]: https://github.com/RustCrypto/block-ciphers/pull/122 
[#86]: https://github.com/RustCrypto/block-ciphers/pull/86

## 0.3.2 (2018-11-01)

## 0.3.1 (2018-10-04)

## 0.3.0 (2018-10-03)

## 0.2.0 (2018-07-27)

## 0.1.0 (2018-06-22)
